﻿$(function () {
    $('[data-tooltip="true"]').tooltip({ container: "body" });
})