#include <iostream>

using namespace std;

int main()
{
    int hversuMorgKvoldSemSiddiReidASidustuThjodhatidALausu;
    cout << "************************************" << endl;
    cout << "*  VELKOMINN I AGISKUNARLEIKINN    *" << endl;
    cout << "************************************" << endl;
    cout << endl;

    cout << "Hvad reid Siddi a morgum kvoldum a sidustu thjodhatid???" << endl;
    do
    {
        cout << "sladu inn stelpufjolda a bilinu 0-20" << endl;
        cin >> hversuMorgKvoldSemSiddiReidASidustuThjodhatidALausu;
        if(hversuMorgKvoldSemSiddiReidASidustuThjodhatidALausu < 0 || hversuMorgKvoldSemSiddiReidASidustuThjodhatidALausu > 20)
        {
            cout << "Endilega fara eftir fyrirmaelum!!!" << endl;
        }
        if(hversuMorgKvoldSemSiddiReidASidustuThjodhatidALausu < 3)
        {
            cout << "Hann var grimmari!!!" << endl;
        }
        if(hversuMorgKvoldSemSiddiReidASidustuThjodhatidALausu > 3)
        {
            cout << "Kaela sig!!!" << endl;
        }
        if(hversuMorgKvoldSemSiddiReidASidustuThjodhatidALausu == 3)
        {
            cout << "************************************" << endl;
            cout << "*  RETT HJA THER!!!!!!!!!!!!!!!    *" << endl;
            cout << "************************************" << endl;
            return 0;
        }

    }
    while(true);
    return 0;
}
